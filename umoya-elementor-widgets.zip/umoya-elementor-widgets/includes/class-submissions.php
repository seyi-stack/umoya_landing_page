<?php
namespace Umoya_EW;

use WP_Error;
use WP_REST_Request;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Submissions {

    const POST_TYPE = 'umoya_submission';

    /**
     * Most submissions a single bulk resend will attempt.
     *
     * Each one is a blocking HTTP call to HubSpot, so an unbounded batch can
     * exceed max_execution_time and abort mid-list. Anything beyond this is
     * reported as deferred and picked up by running the action again.
     */
    const MAX_BULK_RESEND = 25;

    /** Cron hook for one automatic retry of a single submission. */
    const RETRY_HOOK = 'umoya_retry_hubspot_submission';

    /** Hourly safety-net sweep that re-queues failed rows with no pending retry. */
    const SWEEP_HOOK = 'umoya_sweep_failed_submissions';

    /**
     * How many automatic retries a submission gets before it stops.
     *
     * With the backoff in retry_delays() this spans roughly ten days, which is
     * long enough to cover a deploy or a HubSpot form change that makes a
     * previously-rejected payload valid. It is capped rather than infinite so a
     * permanently-invalid payload cannot hammer the API forever.
     */
    const MAX_RETRY_ATTEMPTS = 20;

    /** Failed rows the hourly sweep will re-queue in one pass. */
    const SWEEP_BATCH = 20;

    /** Seconds between each swept retry, so they do not all fire at once. */
    const SWEEP_STAGGER = 120;
    const REST_NAMESPACE = 'umoya/v1';
    const REST_ROUTE = '/submissions';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        add_action( 'add_meta_boxes', array( $this, 'register_meta_boxes' ) );
        add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( $this, 'submission_columns' ) );
        add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( $this, 'render_submission_column' ), 10, 2 );
        add_action( 'admin_post_umoya_resend_submission', array( $this, 'resend_submission' ) );
        /* Screen id for a CPT list table is edit-{post_type}, hence the extra "edit-". */
        add_filter( 'bulk_actions-edit-' . self::POST_TYPE, array( $this, 'register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-' . self::POST_TYPE, array( $this, 'handle_bulk_resend' ), 10, 3 );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
        /* Automatic retry queue */
        add_action( self::RETRY_HOOK, array( $this, 'retry_hubspot_submission' ) );
        add_action( self::SWEEP_HOOK, array( $this, 'sweep_failed_submissions' ) );
        add_action( 'init', array( $this, 'ensure_sweep_scheduled' ) );
        add_action( 'wp_footer', array( $this, 'render_hubspot_tracking_code' ), 20 );
    }

    public function register_post_type() {
        register_post_type(
            self::POST_TYPE,
            array(
                'labels' => array(
                    'name'               => 'Umoya Submissions',
                    'singular_name'      => 'Umoya Submission',
                    'menu_name'          => 'Umoya Submissions',
                    'add_new_item'       => 'Add New Submission',
                    'edit_item'          => 'View Submission',
                    'new_item'           => 'New Submission',
                    'view_item'          => 'View Submission',
                    'search_items'       => 'Search Submissions',
                    'not_found'          => 'No submissions found',
                    'not_found_in_trash' => 'No submissions found in Trash',
                ),
                'public'              => false,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_admin_bar'   => false,
                'exclude_from_search' => true,
                'menu_icon'           => 'dashicons-feedback',
                'supports'            => array( 'title' ),
                'capabilities'        => array(
                    'edit_post'          => 'manage_options',
                    'read_post'          => 'manage_options',
                    'delete_post'        => 'manage_options',
                    'edit_posts'         => 'manage_options',
                    'edit_others_posts'  => 'manage_options',
                    'publish_posts'      => 'manage_options',
                    'read_private_posts' => 'manage_options',
                    'create_posts'       => 'do_not_allow',
                ),
                'map_meta_cap'        => false,
            )
        );
    }

    public function register_rest_routes() {
        register_rest_route(
            self::REST_NAMESPACE,
            self::REST_ROUTE,
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'handle_submission' ),
                'permission_callback' => '__return_true',
            )
        );
    }

    public function handle_submission( WP_REST_Request $request ) {
        $payload = $request->get_json_params();
        if ( ! is_array( $payload ) ) {
            $payload = $request->get_params();
        }

        if ( $this->is_rate_limited() ) {
            return new WP_Error(
                'umoya_rate_limited',
                'Too many submissions. Please wait a few minutes and try again.',
                array( 'status' => 429 )
            );
        }

        $submission = $this->normalize_submission( $payload );
        $existing_id = $this->find_existing_submission( $submission['submission_uuid'] );

        if ( $existing_id ) {
            return rest_ensure_response(
                array(
                    'success'       => true,
                    'saved'         => true,
                    'submissionId'  => $existing_id,
                    'duplicate'     => true,
                    'hubspotStatus' => get_post_meta( $existing_id, '_umoya_hubspot_status', true ),
                )
            );
        }

        if ( empty( $submission['email'] ) || ! is_email( $submission['email'] ) ) {
            return new WP_Error(
                'umoya_invalid_email',
                'A valid email address is required.',
                array( 'status' => 400 )
            );
        }

        if ( empty( $submission['firstname'] ) || empty( $submission['lastname'] ) || empty( $submission['country'] ) ) {
            return new WP_Error(
                'umoya_missing_required_fields',
                'First name, last name, email, and country are required.',
                array( 'status' => 400 )
            );
        }

        $post_id = wp_insert_post(
            array(
                'post_type'   => self::POST_TYPE,
                'post_status' => 'private',
                'post_title'  => $this->build_submission_title( $submission ),
            ),
            true
        );

        if ( is_wp_error( $post_id ) ) {
            return new WP_Error(
                'umoya_save_failed',
                'WordPress could not save the submission.',
                array( 'status' => 500 )
            );
        }

        $this->save_submission_meta( $post_id, $submission, $payload );

        if ( ! empty( $payload['hubspotAlreadySent'] ) ) {
            $hubspot = array(
                'status'   => 'sent_direct_from_browser',
                'code'     => '',
                'response' => 'HubSpot was already sent directly from the browser after the WordPress endpoint was unavailable.',
            );
        } else {
            $hubspot = $this->send_to_hubspot( $submission, $payload );
        }
        $this->record_hubspot_result( $post_id, $hubspot );

        return rest_ensure_response(
            array(
                'success'       => true,
                'saved'         => true,
                'submissionId'  => $post_id,
                'hubspotStatus' => $hubspot['status'],
            )
        );
    }

    public function register_meta_boxes() {
        add_meta_box(
            'umoya_submission_details',
            'Submission Details',
            array( $this, 'render_submission_details' ),
            self::POST_TYPE,
            'normal',
            'high'
        );
    }

    public function render_submission_details( $post ) {
        $fields = array(
            'Submitted At'             => '_umoya_submitted_at',
            'Source'                   => '_umoya_source',
            'First Name'               => '_umoya_firstname',
            'Last Name'                => '_umoya_lastname',
            'Email'                    => '_umoya_email',
            'Phone'                    => '_umoya_phone',
            'Country'                  => '_umoya_country',
            'City'                     => '_umoya_city',
            'Preferred Travel Season'  => '_umoya_preferred_travel_season',
            'Preferred Travel Year'    => '_umoya_preferred_travel_year',
            'How would you like to Travel?' => '_umoya_preferred_journey_length',
            'Message'                  => '_umoya_founders_circle_message',
            'Page URL'                 => '_umoya_page_uri',
            'HubSpot Status'           => '_umoya_hubspot_status',
            'HubSpot Last Attempt'     => '_umoya_hubspot_last_attempt',
            'HubSpot Response Code'    => '_umoya_hubspot_code',
            'HubSpot Response'         => '_umoya_hubspot_response',
            'Submission ID'            => '_umoya_submission_uuid',
            'IP Address'               => '_umoya_ip_address',
            'User Agent'               => '_umoya_user_agent',
        );

        echo '<table class="widefat striped"><tbody>';
        foreach ( $fields as $label => $key ) {
            $value = get_post_meta( $post->ID, $key, true );
            if ( '' === $value ) {
                $value = '-';
            }

            echo '<tr>';
            echo '<th style="width:220px;">' . esc_html( $label ) . '</th>';
            if ( 'HubSpot Status' === $label ) {
                echo '<td>' . $this->status_badge( $value ) . '</td>';
            } elseif ( 'Email' === $label && '-' !== $value ) {
                echo '<td><a href="mailto:' . esc_attr( $value ) . '">' . esc_html( $value ) . '</a></td>';
            } elseif ( 'Page URL' === $label && '-' !== $value ) {
                echo '<td><a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $value ) . '</a></td>';
            } else {
                echo '<td>' . nl2br( esc_html( $value ) ) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';

        $status = get_post_meta( $post->ID, '_umoya_hubspot_status', true );
        $url    = wp_nonce_url(
            admin_url( 'admin-post.php?action=umoya_resend_submission&submission_id=' . absint( $post->ID ) ),
            'umoya_resend_submission_' . absint( $post->ID )
        );

        echo '<p>';
        echo '<a class="button button-primary" href="' . esc_url( $url ) . '">Resend to HubSpot</a>';
        if ( $status ) {
            echo ' <span style="margin-left:8px;">Current HubSpot status: <strong>' . esc_html( $status ) . '</strong></span>';
        }
        echo '</p>';
    }

    public function submission_columns( $columns ) {
        $new_columns = array();
        if ( isset( $columns['cb'] ) ) {
            $new_columns['cb'] = $columns['cb'];
        }

        return array_merge(
            $new_columns,
            array(
                'title'         => 'Submission',
                'umoya_email'   => 'Email',
                'umoya_phone'   => 'Phone',
                'umoya_source'  => 'Source',
                'umoya_hubspot' => 'HubSpot',
                'date'          => 'Date',
            )
        );
    }

    public function render_submission_column( $column, $post_id ) {
        switch ( $column ) {
            case 'umoya_email':
                echo esc_html( get_post_meta( $post_id, '_umoya_email', true ) );
                break;
            case 'umoya_phone':
                echo esc_html( get_post_meta( $post_id, '_umoya_phone', true ) );
                break;
            case 'umoya_source':
                echo esc_html( get_post_meta( $post_id, '_umoya_source', true ) );
                break;
            case 'umoya_hubspot':
                $status = get_post_meta( $post_id, '_umoya_hubspot_status', true );
                echo $this->status_badge( $status ? $status : 'not attempted' );

                /*
                 * Show the auto-retry state so a "failed" row is not mistaken
                 * for something needing manual chasing — and so an exhausted
                 * one is obvious, because nothing will pick that up on its own.
                 */
                if ( 'failed' === $status ) {
                    $attempts = (int) get_post_meta( $post_id, '_umoya_hubspot_retry_attempts', true );
                    $next     = get_post_meta( $post_id, '_umoya_hubspot_next_retry', true );

                    if ( $attempts >= self::MAX_RETRY_ATTEMPTS ) {
                        echo '<br><span style="color:#8B2B2B;font-size:11px;">';
                        echo esc_html(
                            sprintf(
                                /* translators: %d: retry attempt cap. */
                                __( 'auto-retry gave up after %d attempts', 'umoya-elementor-widgets' ),
                                self::MAX_RETRY_ATTEMPTS
                            )
                        );
                        echo '</span>';
                    } elseif ( $next ) {
                        echo '<br><span style="color:#7a7a7a;font-size:11px;">';
                        echo esc_html(
                            sprintf(
                                /* translators: 1: attempts used, 2: cap, 3: local time of next retry. */
                                __( 'retry %1$d/%2$d · next %3$s', 'umoya-elementor-widgets' ),
                                $attempts,
                                self::MAX_RETRY_ATTEMPTS,
                                get_date_from_gmt( $next, 'M j, H:i' )
                            )
                        );
                        echo '</span>';
                    }
                }
                break;
        }
    }

    public function resend_submission() {
        $post_id = isset( $_GET['submission_id'] ) ? absint( $_GET['submission_id'] ) : 0;

        if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) || ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to resend this submission.', 'umoya-elementor-widgets' ) );
        }

        check_admin_referer( 'umoya_resend_submission_' . $post_id );

        $hubspot = $this->resend_one( $post_id );

        wp_safe_redirect(
            add_query_arg(
                array(
                    'post'                 => $post_id,
                    'action'               => 'edit',
                    'umoya_resend_status'  => rawurlencode( $hubspot['status'] ),
                ),
                admin_url( 'post.php' )
            )
        );
        exit;
    }

    /**
     * Resend a single stored submission to HubSpot and record the outcome.
     *
     * Shared by the row action and the bulk action so both paths behave
     * identically — including get_submission_from_meta()'s re-normalisation,
     * which is what lets rows saved before the source-aware alias table
     * succeed on retry.
     *
     * @param int $post_id Submission post ID.
     * @return array{status:string,code:string,response:string}
     */
    private function resend_one( $post_id ) {
        $submission = $this->get_submission_from_meta( $post_id );
        $payload    = array(
            'hubspotPortalId' => get_post_meta( $post_id, '_umoya_hubspot_portal_id', true ),
            'hubspotFormId'   => get_post_meta( $post_id, '_umoya_hubspot_form_id', true ),
            'consentText'     => get_post_meta( $post_id, '_umoya_consent_text', true ),
            'context'         => array(
                'pageUri'  => get_post_meta( $post_id, '_umoya_page_uri', true ),
                'pageName' => get_post_meta( $post_id, '_umoya_page_name', true ),
                'hutk'     => get_post_meta( $post_id, '_umoya_hutk', true ),
            ),
        );

        $hubspot = $this->send_to_hubspot( $submission, $payload );
        $this->record_hubspot_result( $post_id, $hubspot );

        return $hubspot;
    }

    /**
     * Persist the outcome of a HubSpot send and drive the auto-retry queue.
     *
     * Single place every send path funnels through — the REST submit, the row
     * action, the bulk action and the cron retry — so a failure can never be
     * recorded without also being queued for another attempt.
     */
    private function record_hubspot_result( $post_id, $hubspot ) {
        update_post_meta( $post_id, '_umoya_hubspot_status', $hubspot['status'] );
        update_post_meta( $post_id, '_umoya_hubspot_code', $hubspot['code'] );
        update_post_meta( $post_id, '_umoya_hubspot_response', $hubspot['response'] );
        update_post_meta( $post_id, '_umoya_hubspot_last_attempt', current_time( 'mysql' ) );

        if ( 'failed' === $hubspot['status'] ) {
            $this->schedule_retry( $post_id );
            return;
        }

        /*
         * Anything that is not an outright failure ends the retry cycle:
         * 'sent' obviously, 'sent_direct_from_browser' because the browser
         * fallback already delivered it, and 'skipped' because that means the
         * portal/form ID is missing — no amount of retrying fixes a config gap.
         */
        $this->clear_retry( $post_id );
    }

    /**
     * Queue the next automatic retry for a failed submission.
     *
     * Backoff rather than a fixed interval: the first retry is quick (a minute)
     * because most failures are transient — a 5xx, a rate limit, a dropped
     * connection to an origin that already has multi-second TTFB. Later gaps
     * widen so a genuinely unfixable payload (say HubSpot rejecting it with
     * "Required field 'group_type' is missing") cannot sit hammering the API
     * every minute forever. The long tail still spans days, so a submission
     * that only becomes deliverable after a deploy or a HubSpot form change is
     * picked up without anyone touching it.
     */
    private function schedule_retry( $post_id, $stagger = 0 ) {
        $attempts = (int) get_post_meta( $post_id, '_umoya_hubspot_retry_attempts', true );

        if ( $attempts >= self::MAX_RETRY_ATTEMPTS ) {
            delete_post_meta( $post_id, '_umoya_hubspot_next_retry' );
            return;
        }

        // Never stack duplicate events for the same submission.
        if ( wp_next_scheduled( self::RETRY_HOOK, array( $post_id ) ) ) {
            return;
        }

        $delays = self::retry_delays();
        $delay  = isset( $delays[ $attempts ] ) ? $delays[ $attempts ] : end( $delays );
        $when   = time() + $delay + (int) $stagger;

        wp_schedule_single_event( $when, self::RETRY_HOOK, array( $post_id ) );
        update_post_meta( $post_id, '_umoya_hubspot_next_retry', gmdate( 'Y-m-d H:i:s', $when ) );
    }

    private function clear_retry( $post_id ) {
        $timestamp = wp_next_scheduled( self::RETRY_HOOK, array( $post_id ) );

        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::RETRY_HOOK, array( $post_id ) );
            $timestamp = wp_next_scheduled( self::RETRY_HOOK, array( $post_id ) );
        }

        delete_post_meta( $post_id, '_umoya_hubspot_next_retry' );
    }

    /**
     * Seconds to wait before each successive retry.
     *
     * 1m, 2m, 5m, 15m, 30m, 1h, 3h, 6h, 12h, then daily to the attempt cap.
     */
    private static function retry_delays() {
        return array( 60, 120, 300, 900, 1800, 3600, 10800, 21600, 43200, DAY_IN_SECONDS );
    }

    /**
     * Cron callback: one automatic retry for a single submission.
     */
    public function retry_hubspot_submission( $post_id ) {
        $post_id = absint( $post_id );

        if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) ) {
            return;
        }

        if ( 'failed' !== get_post_meta( $post_id, '_umoya_hubspot_status', true ) ) {
            $this->clear_retry( $post_id );
            return;
        }

        $attempts = (int) get_post_meta( $post_id, '_umoya_hubspot_retry_attempts', true );
        update_post_meta( $post_id, '_umoya_hubspot_retry_attempts', $attempts + 1 );

        // resend_one() records the result, which re-queues the next attempt if
        // it failed again, or clears the queue if it finally went through.
        $this->resend_one( $post_id );
    }

    /**
     * Safety net: re-queue failed submissions that have no pending retry.
     *
     * Covers rows that failed before auto-retry existed, and any whose
     * scheduled event was lost — cron flushed, a database restore, a migration.
     * Without this, "fail proof" would only hold for submissions created after
     * this feature shipped.
     */
    public function sweep_failed_submissions() {
        $query = new WP_Query(
            array(
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'any',
                'posts_per_page' => self::SWEEP_BATCH,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array(
                        'key'   => '_umoya_hubspot_status',
                        'value' => 'failed',
                    ),
                ),
            )
        );

        /*
         * Stagger the queued retries a couple of minutes apart.
         *
         * WP-Cron runs every due event inside ONE wp-cron.php invocation,
         * sequentially. Queueing a batch for the same moment would mean one PHP
         * worker held open for batch x (HubSpot round trip) seconds. This
         * origin is already resource-starved — it currently 522s even on static
         * files — so a self-healing feature must not add a thundering herd to
         * it. Spacing them means at most one retry per cron tick.
         */
        $index = 0;
        foreach ( $query->posts as $post_id ) {
            if ( wp_next_scheduled( self::RETRY_HOOK, array( $post_id ) ) ) {
                continue;
            }

            if ( (int) get_post_meta( $post_id, '_umoya_hubspot_retry_attempts', true ) >= self::MAX_RETRY_ATTEMPTS ) {
                continue;
            }

            $this->schedule_retry( $post_id, $index * self::SWEEP_STAGGER );
            $index++;
        }
    }

    /**
     * Make sure the hourly sweep exists. Cheap: wp_next_scheduled() guards it.
     */
    public function ensure_sweep_scheduled() {
        if ( ! wp_next_scheduled( self::SWEEP_HOOK ) ) {
            wp_schedule_event( time() + 300, 'hourly', self::SWEEP_HOOK );
        }
    }

    /**
     * Remove every scheduled retry/sweep. Called on plugin deactivation so the
     * site is not left with orphaned cron entries.
     */
    public static function clear_all_scheduled_events() {
        wp_clear_scheduled_hook( self::SWEEP_HOOK );

        $query = new WP_Query(
            array(
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            )
        );

        foreach ( $query->posts as $post_id ) {
            wp_clear_scheduled_hook( self::RETRY_HOOK, array( (int) $post_id ) );
        }
    }

    /**
     * Add the resend options to the submissions list bulk-action dropdown.
     *
     * Two variants on purpose: "failed only" is the safe one for fixing a
     * backlog, because re-sending an already-sent row creates a duplicate
     * submission record in HubSpot and skews that form's conversion numbers.
     */
    public function register_bulk_actions( $actions ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return $actions;
        }

        $actions['umoya_resend_hubspot_failed'] = __( 'Resend to HubSpot (failed only)', 'umoya-elementor-widgets' );
        $actions['umoya_resend_hubspot']        = __( 'Resend to HubSpot (all selected)', 'umoya-elementor-widgets' );

        return $actions;
    }

    /**
     * Run the bulk resend.
     *
     * WordPress verifies the bulk-action nonce before this filter fires, but
     * the capability is re-checked here because the filter is reachable
     * independently of the dropdown being rendered.
     */
    public function handle_bulk_resend( $redirect_to, $doaction, $post_ids ) {
        $failed_only = ( 'umoya_resend_hubspot_failed' === $doaction );

        if ( 'umoya_resend_hubspot' !== $doaction && ! $failed_only ) {
            return $redirect_to;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return $redirect_to;
        }

        $sent     = 0;
        $failed   = 0;
        $skipped  = 0;
        $deferred = 0;

        foreach ( (array) $post_ids as $post_id ) {
            $post_id = absint( $post_id );

            if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) ) {
                continue;
            }

            if ( $failed_only && 'sent' === get_post_meta( $post_id, '_umoya_hubspot_status', true ) ) {
                $skipped++;
                continue;
            }

            /*
             * Every resend is a blocking HTTP round trip, and this origin is
             * already slow (multi-second TTFB). Cap the batch so a large
             * selection cannot hit max_execution_time and leave the tail of
             * the list in an unknown state — the notice tells the user how
             * many were deferred so they can simply run it again.
             */
            if ( ( $sent + $failed ) >= self::MAX_BULK_RESEND ) {
                $deferred++;
                continue;
            }

            $result = $this->resend_one( $post_id );

            if ( 'sent' === $result['status'] ) {
                $sent++;
            } else {
                $failed++;
            }
        }

        return add_query_arg(
            array(
                'umoya_bulk_sent'     => $sent,
                'umoya_bulk_failed'   => $failed,
                'umoya_bulk_skipped'  => $skipped,
                'umoya_bulk_deferred' => $deferred,
            ),
            $redirect_to
        );
    }

    public function admin_notices() {
        // Single-row resend
        if ( isset( $_GET['umoya_resend_status'] ) ) {
            $status = sanitize_text_field( wp_unslash( $_GET['umoya_resend_status'] ) );
            $class  = 'sent' === $status ? 'notice notice-success' : 'notice notice-warning';

            echo '<div class="' . esc_attr( $class ) . '"><p>';
            echo esc_html( 'HubSpot resend status: ' . $status );
            echo '</p></div>';
        }

        // Bulk resend
        if ( isset( $_GET['umoya_bulk_sent'] ) || isset( $_GET['umoya_bulk_failed'] ) ) {
            $sent     = isset( $_GET['umoya_bulk_sent'] ) ? absint( $_GET['umoya_bulk_sent'] ) : 0;
            $failed   = isset( $_GET['umoya_bulk_failed'] ) ? absint( $_GET['umoya_bulk_failed'] ) : 0;
            $skipped  = isset( $_GET['umoya_bulk_skipped'] ) ? absint( $_GET['umoya_bulk_skipped'] ) : 0;
            $deferred = isset( $_GET['umoya_bulk_deferred'] ) ? absint( $_GET['umoya_bulk_deferred'] ) : 0;

            $parts = array();
            /* translators: %d: number of submissions. */
            $parts[] = sprintf( _n( '%d sent', '%d sent', $sent, 'umoya-elementor-widgets' ), $sent );

            if ( $failed ) {
                $parts[] = sprintf( _n( '%d failed', '%d failed', $failed, 'umoya-elementor-widgets' ), $failed );
            }
            if ( $skipped ) {
                $parts[] = sprintf( _n( '%d already sent (skipped)', '%d already sent (skipped)', $skipped, 'umoya-elementor-widgets' ), $skipped );
            }

            $class = $failed ? 'notice notice-warning' : 'notice notice-success';

            echo '<div class="' . esc_attr( $class ) . ' is-dismissible"><p>';
            echo esc_html( 'HubSpot bulk resend: ' . implode( ', ', $parts ) . '.' );

            if ( $deferred ) {
                echo ' ';
                echo esc_html(
                    sprintf(
                        /* translators: 1: number deferred, 2: per-run cap. */
                        __( '%1$d were not attempted because this run hit the %2$d-per-batch limit — run the action again to continue.', 'umoya-elementor-widgets' ),
                        $deferred,
                        self::MAX_BULK_RESEND
                    )
                );
            }

            if ( $failed ) {
                echo ' ';
                echo esc_html( __( 'Open a failed row to see the HubSpot response code and body.', 'umoya-elementor-widgets' ) );
            }

            echo '</p></div>';
        }
    }

    public function render_hubspot_tracking_code() {
        if ( is_admin() ) {
            return;
        }
        ?>
        <script>
        (function(d,s,id){
          if(d.getElementById(id)) return;
          var js=d.createElement(s);
          js.id=id;
          js.async=true;
          js.defer=true;
          js.src='https://js.hs-scripts.com/246097317.js';
          var first=d.getElementsByTagName(s)[0];
          if(first && first.parentNode){ first.parentNode.insertBefore(js, first); }
          else { d.head.appendChild(js); }
        }(document,'script','hs-script-loader'));
        </script>
        <?php
    }

    private function normalize_submission( $payload ) {
        $field_values = array();

        if ( isset( $payload['fields'] ) && is_array( $payload['fields'] ) ) {
            foreach ( $payload['fields'] as $field ) {
                if ( ! is_array( $field ) || empty( $field['name'] ) ) {
                    continue;
                }

                $field_values[ sanitize_key( $field['name'] ) ] = $this->clean_value( isset( $field['value'] ) ? $field['value'] : '' );
            }
        }

        $raw_fields = array();
        if ( isset( $payload['rawFields'] ) && is_array( $payload['rawFields'] ) ) {
            foreach ( $payload['rawFields'] as $name => $value ) {
                $raw_fields[ sanitize_key( $name ) ] = $this->clean_value( $value );
            }
        }

        foreach ( $payload as $name => $value ) {
            if ( is_array( $value ) || in_array( $name, array( 'fields', 'rawFields', 'context', 'legalConsentOptions' ), true ) ) {
                continue;
            }

            $raw_fields[ sanitize_key( $name ) ] = $this->clean_value( $value );
        }

        /*
         * Default alias map — used by the Founder's Circle page and the
         * homepage popup, which both post to the shared HubSpot form.
         */
        $aliases = array(
            'salutation'                  => array( 'salutation', 'merge1', 'title' ),
            'firstname'                   => array( 'firstname', 'fname' ),
            'lastname'                    => array( 'lastname', 'lname' ),
            'email'                       => array( 'email' ),
            'phone'                       => array( 'phone' ),
            'country'                     => array( 'country', 'merge2' ),
            'city'                        => array( 'city', 'merge3' ),
            'preferred_travel_season'     => array( 'preferred_travel_season', 'merge4', 'season' ),
            'preferred_travel_year'       => array( 'preferred_travel_year', 'merge5', 'year' ),
            'preferred_journey_length'    => array( 'preferred_journey_length', 'merge6', 'length' ),
            'founders_circle_message'     => array( 'founders_circle_message', 'merge7', 'message' ),
        );

        /*
         * Source-aware overrides.
         *
         * Private & Tailormade and For Groups now submit to their own HubSpot
         * forms and write DEDICATED properties, so their MERGE* slots must not
         * keep landing in country/city/preferred_journey_length. Each override
         * also re-declares the borrowed key WITHOUT its merge alias, otherwise
         * e.g. merge2 would populate both trip_occasion and country.
         *
         * Keys here mirror the hubspotFieldMap in each page's form script.
         */
        $source_aliases = array(
            'private_tailormade_page'  => array(
                'trip_occasion'            => array( 'trip_occasion', 'merge2' ),
                'party_size'               => array( 'party_size', 'merge6' ),
                'country'                  => array( 'country' ),
                'preferred_journey_length' => array( 'preferred_journey_length' ),
            ),
            'for_groups_page'          => array(
                'group_type'               => array( 'group_type', 'merge2' ),
                'organization'             => array( 'organization', 'merge3' ),
                'party_size'               => array( 'party_size', 'merge6' ),
                'country'                  => array( 'country' ),
                'city'                     => array( 'city' ),
                'preferred_journey_length' => array( 'preferred_journey_length' ),
            ),
            /*
             * These three keep country/city, but their MERGE6 select is
             * "How Many Guests Will Be Traveling?" — a party size, not a
             * journey length. Correcting the target loses nothing: the old
             * `preferred_journey_length` property did not exist until
             * 2026-08-11, so it never captured a single value.
             */
            'founders_circle_page'     => array(
                'party_size'               => array( 'party_size', 'merge6' ),
                'preferred_journey_length' => array( 'preferred_journey_length' ),
            ),
            'homepage_popup'           => array(
                'party_size'               => array( 'party_size', 'merge6' ),
                'preferred_journey_length' => array( 'preferred_journey_length' ),
            ),
            'signature_journey_popup'  => array(
                'party_size'               => array( 'party_size', 'merge6' ),
                'preferred_journey_length' => array( 'preferred_journey_length' ),
            ),
        );

        $source_key = isset( $payload['source'] ) ? sanitize_key( $payload['source'] ) : '';
        if ( $source_key && isset( $source_aliases[ $source_key ] ) ) {
            $aliases = array_merge( $aliases, $source_aliases[ $source_key ] );
        }

        $submission = array();
        foreach ( $aliases as $target => $keys ) {
            $submission[ $target ] = '';
            foreach ( $keys as $key ) {
                if ( ! empty( $field_values[ $key ] ) ) {
                    $submission[ $target ] = $field_values[ $key ];
                    break;
                }
                if ( ! empty( $raw_fields[ $key ] ) ) {
                    $submission[ $target ] = $raw_fields[ $key ];
                    break;
                }
            }
        }

        $context = isset( $payload['context'] ) && is_array( $payload['context'] ) ? $payload['context'] : array();
        $cookie_hutk = isset( $_COOKIE['hubspotutk'] ) ? $this->clean_value( $_COOKIE['hubspotutk'] ) : '';

        $submission['source']             = $this->clean_value( isset( $payload['source'] ) ? $payload['source'] : 'umoya_form' );
        $submission['page_uri']           = esc_url_raw( isset( $context['pageUri'] ) ? $context['pageUri'] : ( isset( $payload['pageUri'] ) ? $payload['pageUri'] : ( isset( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : '' ) ) );
        $submission['page_name']          = $this->clean_value( isset( $context['pageName'] ) ? $context['pageName'] : ( isset( $payload['pageName'] ) ? $payload['pageName'] : '' ) );
        $submission['hutk']               = $this->clean_value( isset( $context['hutk'] ) && $context['hutk'] ? $context['hutk'] : ( isset( $payload['hutk'] ) && $payload['hutk'] ? $payload['hutk'] : $cookie_hutk ) );
        $submission['hubspot_portal_id']  = $this->clean_value( isset( $payload['hubspotPortalId'] ) ? $payload['hubspotPortalId'] : '' );
        $submission['hubspot_form_id']    = $this->clean_value( isset( $payload['hubspotFormId'] ) ? $payload['hubspotFormId'] : '' );
        $submission['consent_text']       = $this->clean_value( isset( $payload['consentText'] ) ? $payload['consentText'] : '' );
        $submission['submission_uuid']    = $this->normalize_uuid( isset( $payload['submissionId'] ) ? $payload['submissionId'] : '' );
        $submission['submitted_at']       = current_time( 'mysql' );
        $submission['ip_address']         = $this->get_client_ip();
        $submission['user_agent']         = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

        return $submission;
    }

    private function save_submission_meta( $post_id, $submission, $payload ) {
        foreach ( $submission as $key => $value ) {
            update_post_meta( $post_id, '_umoya_' . $key, $value );
        }

        update_post_meta( $post_id, '_umoya_payload', wp_json_encode( $payload ) );
        update_post_meta( $post_id, '_umoya_hubspot_status', 'not attempted' );
    }

    private function send_to_hubspot( $submission, $payload ) {
        $portal_id = isset( $payload['hubspotPortalId'] ) ? $this->clean_value( $payload['hubspotPortalId'] ) : $submission['hubspot_portal_id'];
        $form_id   = isset( $payload['hubspotFormId'] ) ? $this->clean_value( $payload['hubspotFormId'] ) : $submission['hubspot_form_id'];

        if ( ! $portal_id || ! $form_id ) {
            return array(
                'status'   => 'skipped',
                'code'     => '',
                'response' => 'HubSpot Portal ID or Form ID is missing.',
            );
        }

        $hubspot_fields = array();
        foreach ( $this->hubspot_field_names() as $key ) {
            if ( ! empty( $submission[ $key ] ) ) {
                $hubspot_fields[] = array(
                    'name'  => $key,
                    'value' => $submission[ $key ],
                );
            }
        }

        $context = isset( $payload['context'] ) && is_array( $payload['context'] ) ? $payload['context'] : array();
        $body    = array(
            'fields'  => $hubspot_fields,
            'context' => array_filter(
                array(
                    'pageUri'  => isset( $context['pageUri'] ) ? esc_url_raw( $context['pageUri'] ) : $submission['page_uri'],
                    'pageName' => isset( $context['pageName'] ) ? $this->clean_value( $context['pageName'] ) : $submission['page_name'],
                    'hutk'     => isset( $context['hutk'] ) ? $this->clean_value( $context['hutk'] ) : $submission['hutk'],
                    'ipAddress'=> $submission['ip_address'],
                )
            ),
        );

        $consent_text = isset( $payload['consentText'] ) ? $this->clean_value( $payload['consentText'] ) : $submission['consent_text'];
        if ( $consent_text ) {
            $body['legalConsentOptions'] = array(
                'consent' => array(
                    'consentToProcess' => true,
                    'text'             => $consent_text,
                ),
            );
        }

        $response = wp_remote_post(
            'https://api.hsforms.com/submissions/v3/integration/submit/' . rawurlencode( $portal_id ) . '/' . rawurlencode( $form_id ),
            array(
                'timeout' => 15,
                'headers' => array(
                    'Content-Type' => 'application/json',
                ),
                'body'    => wp_json_encode( $body ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return array(
                'status'   => 'failed',
                'code'     => '',
                'response' => $response->get_error_message(),
            );
        }

        $code          = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );

        return array(
            'status'   => $code >= 200 && $code < 300 ? 'sent' : 'failed',
            'code'     => (string) $code,
            'response' => $response_body,
        );
    }

    /**
     * Every HubSpot contact property any Umoya form can populate.
     *
     * This is the union across all sources. send_to_hubspot() skips empty
     * values, so listing a property a given form never fills is harmless.
     * The last four are the dedicated properties used by the Private &
     * Tailormade and For Groups forms instead of borrowing country/city.
     */
    private function hubspot_field_names() {
        return array(
            'salutation',
            'firstname',
            'lastname',
            'email',
            'phone',
            'country',
            'city',
            'preferred_travel_season',
            'preferred_travel_year',
            'preferred_journey_length',
            'founders_circle_message',
            'trip_occasion',
            'party_size',
            'group_type',
            'organization',
        );
    }

    private function get_submission_from_meta( $post_id ) {
        $submission = array();
        foreach ( array_merge( $this->hubspot_field_names(), array( 'hubspot_portal_id', 'hubspot_form_id', 'consent_text', 'page_uri', 'page_name', 'hutk' ) ) as $key ) {
            $submission[ $key ] = get_post_meta( $post_id, '_umoya_' . $key, true );
        }

        /*
         * Submissions stored before the source-aware alias table shipped put
         * the group type in `country`, the organisation in `city` and the
         * party size in `preferred_journey_length`. Their dedicated
         * properties are therefore empty in meta, so a plain resend would
         * still fail the "Required field 'group_type' is missing" check on
         * the Group Journey / Private & Tailormade forms.
         *
         * The untouched request body is kept in _umoya_payload, so
         * re-normalise from that instead. The re-normalised values replace
         * the whole HubSpot field set rather than merging into it, otherwise
         * the old value would linger in `country` and be sent alongside the
         * new `group_type`. This is what lets "Resend to HubSpot" recover
         * historical failures.
         */
        $raw_payload = get_post_meta( $post_id, '_umoya_payload', true );
        if ( $raw_payload ) {
            $payload = json_decode( $raw_payload, true );
            if ( is_array( $payload ) ) {
                $renormalized = $this->normalize_submission( $payload );
                foreach ( $this->hubspot_field_names() as $key ) {
                    $submission[ $key ] = isset( $renormalized[ $key ] ) ? $renormalized[ $key ] : '';
                }
            }
        }

        return $submission;
    }

    private function build_submission_title( $submission ) {
        $name = trim( $submission['firstname'] . ' ' . $submission['lastname'] );
        if ( ! $name ) {
            $name = $submission['email'];
        }

        return sprintf(
            '%s - %s',
            $name,
            current_time( 'Y-m-d H:i' )
        );
    }

    private function clean_value( $value ) {
        if ( is_array( $value ) ) {
            $value = implode( ', ', array_map( 'sanitize_text_field', wp_unslash( $value ) ) );
        }

        return sanitize_textarea_field( wp_unslash( (string) $value ) );
    }

    private function normalize_uuid( $value ) {
        $value = sanitize_text_field( wp_unslash( (string) $value ) );

        if ( ! $value ) {
            return wp_generate_uuid4();
        }

        return preg_match( '/^[a-zA-Z0-9_-]{8,80}$/', $value ) ? $value : wp_generate_uuid4();
    }

    private function find_existing_submission( $submission_uuid ) {
        if ( ! $submission_uuid ) {
            return 0;
        }

        $existing = get_posts(
            array(
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'private',
                'fields'         => 'ids',
                'posts_per_page' => 1,
                'meta_key'       => '_umoya_submission_uuid',
                'meta_value'     => $submission_uuid,
            )
        );

        return $existing ? absint( $existing[0] ) : 0;
    }

    private function status_badge( $status ) {
        $status = $status ? $status : 'not attempted';
        $colors = array(
            'sent'                     => array( '#0f7b3f', '#e7f6ed' ),
            'sent_direct_from_browser' => array( '#2563eb', '#eff6ff' ),
            'failed'                   => array( '#b42318', '#fef3f2' ),
            'skipped'                  => array( '#92400e', '#fffbeb' ),
            'not attempted'            => array( '#475467', '#f2f4f7' ),
        );
        $color = isset( $colors[ $status ] ) ? $colors[ $status ] : $colors['not attempted'];

        return sprintf(
            '<span style="display:inline-flex;align-items:center;padding:3px 8px;border-radius:999px;font-size:12px;font-weight:600;color:%1$s;background:%2$s;">%3$s</span>',
            esc_attr( $color[0] ),
            esc_attr( $color[1] ),
            esc_html( str_replace( '_', ' ', $status ) )
        );
    }

    private function get_client_ip() {
        $headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );

        foreach ( $headers as $header ) {
            if ( empty( $_SERVER[ $header ] ) ) {
                continue;
            }

            $value = sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) );
            $parts = explode( ',', $value );
            $ip    = trim( $parts[0] );

            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return $ip;
            }
        }

        return '';
    }

    private function is_rate_limited() {
        $ip = $this->get_client_ip();
        if ( ! $ip ) {
            return false;
        }

        $key   = 'umoya_submission_rate_' . md5( $ip );
        $count = (int) get_transient( $key );

        if ( $count >= 8 ) {
            return true;
        }

        set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );
        return false;
    }
}
