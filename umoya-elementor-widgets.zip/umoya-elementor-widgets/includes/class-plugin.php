<?php
/**
 * Elementor integration: categories, widget registration and asset handles.
 *
 * Every section widget is compiled by tools/uew and registered from
 * includes/sections/index.json. There is one code path now; the
 * first-generation generator and its Base_Widget were retired once the homepage
 * migrated, so a section can no longer be half on one system and half on the
 * other.
 *
 * @package Umoya_EW
 */

namespace Umoya_EW;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_categories' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_styles' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_scripts' ) );
		add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_editor_styles' ) );
	}

	public function register_categories( $elements_manager ) {
		require_once UMOYA_EW_PATH . 'includes/class-section-registry.php';

		foreach ( Section_Registry::categories() as $category ) {
			$elements_manager->add_category(
				$category['slug'],
				array(
					'title' => $category['title'],
					'icon'  => ! empty( $category['icon'] ) ? $category['icon'] : 'eicon-globe',
				)
			);
		}
	}

	public function register_widgets( $widgets_manager ) {
		require_once UMOYA_EW_PATH . 'includes/class-value-formatter.php';
		require_once UMOYA_EW_PATH . 'includes/class-section-registry.php';
		require_once UMOYA_EW_PATH . 'includes/class-control-factory.php';
		require_once UMOYA_EW_PATH . 'includes/class-section-widget.php';

		foreach ( Section_Registry::widgets() as $section ) {
			$file = UMOYA_EW_PATH . ltrim( $section['widget_file'], '/\\' );
			if ( ! file_exists( $file ) ) {
				continue;
			}

			require_once $file;

			$class = '\\Umoya_EW\\Widgets\\' . $section['class_name'];
			if ( class_exists( $class ) ) {
				$widgets_manager->register( new $class() );
			}
		}
	}

	public function register_styles() {
		foreach ( Section_Registry::styles() as $handle => $style ) {
			wp_register_style(
				$handle,
				UMOYA_EW_URL . ltrim( $style['file'], '/\\' ),
				$style['deps'],
				UMOYA_EW_VERSION
			);
		}
	}

	public function register_scripts() {
		foreach ( Section_Registry::scripts() as $handle => $script ) {
			wp_register_script(
				$handle,
				UMOYA_EW_URL . ltrim( $script['file'], '/\\' ),
				$script['deps'],
				UMOYA_EW_VERSION,
				true
			);
		}
	}

	/**
	 * The editor iframe does not go through the frontend enqueue path for widgets
	 * that are not yet on the page, so every section stylesheet is loaded there.
	 * Without it a freshly dragged-in section renders unstyled until reload.
	 */
	public function enqueue_editor_styles() {
		$this->register_styles();

		foreach ( array_keys( Section_Registry::styles() ) as $handle ) {
			wp_enqueue_style( $handle );
		}
	}
}
