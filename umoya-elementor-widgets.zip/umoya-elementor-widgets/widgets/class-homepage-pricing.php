<?php
namespace Umoya_EW\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Homepage_Pricing extends \Umoya_EW\Base_Widget {

    protected function section_key() {
        return 'homepage_pricing';
    }
}
